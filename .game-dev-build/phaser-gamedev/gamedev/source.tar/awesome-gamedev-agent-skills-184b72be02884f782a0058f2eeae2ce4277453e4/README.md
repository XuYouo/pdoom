<!-- markdownlint-disable MD033 MD041 -->

# awesome-gamedev-agent-skills

<p align="center">
  <img src="docs/assets/awesome-gamedev-agent-skills-banner.png" width="820"
       alt="awesome-gamedev-agent-skills — game-dev skills for AI coding agents. 76 skills and a router across 12 engines, including an art-direction and asset-production workflow.">
</p>

**76 game-dev skills for your AI coding agent — install once, and a router loads the
right skill for whatever you're building.**

[![License](https://img.shields.io/badge/license-Apache--2.0-blue)](LICENSE)
[![Skills](https://img.shields.io/badge/skills-76%20%2B%20router-brightgreen)](skills/)
[![Format](https://img.shields.io/badge/format-Agent%20Skills-informational)](docs/SKILL-FORMAT.md)
[![Last commit](https://img.shields.io/github/last-commit/gamedev-skills/awesome-gamedev-agent-skills)](https://github.com/gamedev-skills/awesome-gamedev-agent-skills/commits/main)

[Agent Skills](docs/SKILL-FORMAT.md) are small capability files an AI agent loads only when it
needs them. This repo gives your agent **76 game-dev skills** and a **router** that picks the
right ones for you. You describe what you're building; the agent loads the matching engine and
task skills before it writes code.

- **Cross-engine.** Godot, Unity, Unreal, Ebitengine, Phaser, PixiJS, three.js, Bevy, pygame, LÖVE, Defold, Roblox.
- **You don't pick skills.** The router detects your engine and task and loads only what fits.
- **Art direction, not one-off generations.** The asset workflow locks a visual target, builds
  families, normalizes outputs deterministically, and checks them inside the game.
- **Built to trust.** Every skill is written from primary docs, version-pinned to a stated
  engine release, and checked by a [validator](scripts/validate-skills.py). Current baselines and
  upgrade policy live in [version support](docs/VERSION-SUPPORT.md).

## Contents

- [Quick start](#quick-start)
- [What you can ask](#what-you-can-ask)
- [How the router picks skills](#how-the-router-picks-skills)
- [Catalog](#catalog)
- [Agent compatibility](#agent-compatibility)
- [Contributing](#contributing)

## Quick start

**One command, any agent.** The [`skills`](https://www.npmjs.com/package/skills) CLI detects the
coding agent you already use and installs the router plus all 76 skills into the right place:

```bash
npx skills add gamedev-skills/awesome-gamedev-agent-skills
```

Add `--list` to preview first, `-g` to install for every project, or `-a <agent>` to target a
specific tool (`-a cursor`, `-a claude-code`, `-a gemini-cli`, …). The CLI needs Node.js 22.20 or
later. The same `SKILL.md` files load
natively in Claude Code, Cursor, Windsurf, Cline, Codex, Gemini CLI, GitHub Copilot, Kiro, and
[dozens more](docs/COMPATIBILITY.md) — there's nothing to convert.

**Claude Code plugin (alternative).** This repo is also a Claude Code plugin marketplace, so you
can install it with Claude's own commands:

```bash
claude plugin marketplace add gamedev-skills/awesome-gamedev-agent-skills
claude plugin install gamedev@awesome-gamedev-agent-skills
```

Building in only one engine? Install a smaller bundle — `router` plus your engine:

```bash
claude plugin install router@awesome-gamedev-agent-skills
claude plugin install godot@awesome-gamedev-agent-skills    # or: unity · unreal · ebitengine · web-engines · other-engines
```

Prefer to copy the files by hand, or want the exact per-tool paths? See
**[`docs/INSTALLATION.md`](docs/INSTALLATION.md)**.

Want to read the catalog as web pages instead? Every skill, engine group, and per-agent install
path is browsable at
**[gamedev-skills.github.io/awesome-gamedev-agent-skills](https://gamedev-skills.github.io/awesome-gamedev-agent-skills/)**,
generated straight from the `SKILL.md` files in this repo.

Then just talk to your agent — see below.

## What you can ask

Describe the task in plain language. The router figures out the skills:

| You say | Skills it loads for you |
|---------|-------------------------|
| "add a double jump to my Godot player" | `godot-2d-movement` + `platformer` |
| "make an inventory for my Unity RPG" | `unity-scriptableobjects` + `rpg` + `save-systems` |
| "build a 2D puzzle in Go with Ebitengine" | `ebitengine-game` + `puzzle` |
| "add player movement to my Defold game" | `defold-core` + `input-systems` |
| "procedural dungeon roguelike in Godot" | `godot-tilemap` + `procedural-gen` + `roguelike` |
| "make a cohesive pixel-art player, enemies, and tiles" | `create-game-assets` + the detected engine importer |
| "how should I design save slots?" | `save-systems` |
| "publish my game on itch with butler" | `itch-publish` |

You never type the skill names on the right. That's the router's job.

## How the router picks skills

You never name a skill. On each request the router does three things:

1. **Detects your engine** from project files — a `project.godot` means Godot, a `*.uproject`
   means Unreal, and so on. If it can't tell, it just asks.
2. **Reads your request** for the task — a concept (AI, shaders, saving), a genre (platformer,
   roguelike), or a shipping step (game jam, Steam).
3. **Loads only the matching skills**, in order: engine basics first, then the concept, then any
   genre glue. It re-routes if you switch to something new.

That's why "add a double jump to my Godot player" loads `godot-2d-movement` + `platformer` and
nothing else.

<details>
<summary>The exact detection signals and routing table</summary>

The full algorithm — every engine fingerprint, the task-to-skill table, and how engine,
discipline, genre, and workflow skills compose — lives in the router skill itself:
[`router/SKILL.md`](router/SKILL.md). In short: engine selection is exclusive (exactly one
engine), while disciplines, genres, and workflows are additive on top.

</details>

## Catalog

76 skills across 9 categories — each links to its `SKILL.md` below.

### Engines

#### Godot — 16 ([`skills/godot/`](skills/godot/)) · Godot 4.7

| Skill | Scope |
|-------|-------|
| [`godot-gdscript`](skills/godot/godot-gdscript/SKILL.md) | GDScript language: typing, lifecycle, `@export`, signals, idioms |
| [`godot-nodes-scenes`](skills/godot/godot-nodes-scenes/SKILL.md) | Scene tree, node composition, instancing, autoloads, `PackedScene` |
| [`godot-signals-groups`](skills/godot/godot-signals-groups/SKILL.md) | Event-driven design with signals + groups |
| [`godot-2d-movement`](skills/godot/godot-2d-movement/SKILL.md) | `CharacterBody2D` kinematic movement, `move_and_slide`, slopes |
| [`godot-tilemap`](skills/godot/godot-tilemap/SKILL.md) | `TileMapLayer`/`TileSet`: autotiling, terrain, collision/nav layers |
| [`godot-physics`](skills/godot/godot-physics/SKILL.md) | Rigid/Area/Static bodies (2D+3D), collision layers, raycasts |
| [`godot-ui-control`](skills/godot/godot-ui-control/SKILL.md) | `Control` nodes: anchors, containers, themes, focus nav |
| [`godot-animation`](skills/godot/godot-animation/SKILL.md) | `AnimationPlayer`, `AnimationTree`, `Tween` |
| [`godot-shaders`](skills/godot/godot-shaders/SKILL.md) | Godot shading language: 2D `canvas_item` + 3D `spatial` shaders |
| [`godot-3d-essentials`](skills/godot/godot-3d-essentials/SKILL.md) | 3D nodes, cameras, lighting, environment/post, `GridMap` |
| [`godot-resources`](skills/godot/godot-resources/SKILL.md) | Custom `Resource` classes, `.tres`, data-driven design |
| [`godot-audio`](skills/godot/godot-audio/SKILL.md) | `AudioStreamPlayer`, buses, effects, sync-to-beat |
| [`godot-multiplayer`](skills/godot/godot-multiplayer/SKILL.md) | High-level multiplayer: `MultiplayerAPI`, RPCs, spawner/sync |
| [`godot-export`](skills/godot/godot-export/SKILL.md) | Export presets/templates, platform builds, headless CLI export |
| [`godot-csharp`](skills/godot/godot-csharp/SKILL.md) | C#/.NET in Godot: bindings, signals as events, GDScript interop |
| [`godot-gdscript-headless-testing`](skills/godot/godot-gdscript-headless-testing/SKILL.md) | Run GDScript tests via `godot --headless`, exit codes for CI |

#### Unity — 8 ([`skills/unity/`](skills/unity/)) · Unity 6.3 LTS (6000.3)

| Skill | Scope |
|-------|-------|
| [`unity-csharp-scripting`](skills/unity/unity-csharp-scripting/SKILL.md) | `MonoBehaviour` lifecycle, component model, coroutines, serialization |
| [`unity-input-system`](skills/unity/unity-input-system/SKILL.md) | New Input System: actions, bindings, action maps, devices |
| [`unity-physics`](skills/unity/unity-physics/SKILL.md) | Rigidbody, colliders, layers, joints |
| [`unity-animation`](skills/unity/unity-animation/SKILL.md) | Animator Controllers, state machines, blend trees, humanoid IK |
| [`unity-scriptableobjects`](skills/unity/unity-scriptableobjects/SKILL.md) | Data architecture with `ScriptableObject` |
| [`unity-tilemap-2d`](skills/unity/unity-tilemap-2d/SKILL.md) | 2D Tilemap/Tile Palette, rule tiles, tilemap colliders |
| [`unity-navmesh`](skills/unity/unity-navmesh/SKILL.md) | AI navigation: NavMesh bake, `NavMeshAgent` |
| [`unity-build-pipeline`](skills/unity/unity-build-pipeline/SKILL.md) | Build/player/quality settings, code stripping, Addressables |

#### Unreal — 6 ([`skills/unreal/`](skills/unreal/)) · Unreal Engine 5.8

| Skill | Scope |
|-------|-------|
| [`unreal-blueprints`](skills/unreal/unreal-blueprints/SKILL.md) | Blueprint visual scripting: classes, graphs, comms, common nodes |
| [`unreal-cpp-gameplay`](skills/unreal/unreal-cpp-gameplay/SKILL.md) | C++ gameplay + Gameplay Framework (GameMode, Pawn, Controller) |
| [`unreal-enhanced-input`](skills/unreal/unreal-enhanced-input/SKILL.md) | Enhanced Input: Input Actions, Mapping Contexts, Modifiers, Triggers |
| [`unreal-behavior-trees`](skills/unreal/unreal-behavior-trees/SKILL.md) | AI Behavior Trees + Blackboard, tasks/decorators/services |
| [`unreal-niagara`](skills/unreal/unreal-niagara/SKILL.md) | Niagara VFX: systems, emitters, modules, parameters |
| [`unreal-packaging`](skills/unreal/unreal-packaging/SKILL.md) | Packaging/cooking projects, build configs, shipping builds |

#### Ebitengine — 1 ([`skills/ebitengine/`](skills/ebitengine/)) · Ebitengine v2.10.5 · Go 1.25+

| Skill | Scope |
|-------|-------|
| [`ebitengine-game`](skills/ebitengine/ebitengine-game/SKILL.md) | Playable Go 2D games: update/draw contracts, input, rendering, text, audio, gameplay tests, optional starter and platform builds |

#### Web engines — 6 ([`skills/web-engines/`](skills/web-engines/)) · Phaser 4.2 · PixiJS 8.22 · three.js r186

| Skill | Scope |
|-------|-------|
| [`phaser-core`](skills/web-engines/phaser-core/SKILL.md) | Phaser 4.2 game config, Scene lifecycle, loader, cameras |
| [`phaser-arcade-physics`](skills/web-engines/phaser-arcade-physics/SKILL.md) | Arcade Physics: bodies, velocity, colliders/overlap, groups |
| [`pixijs-rendering`](skills/web-engines/pixijs-rendering/SKILL.md) | PixiJS v8 scene graph: `Application`, `Container`, `Sprite`, events |
| [`threejs-scene-setup`](skills/web-engines/threejs-scene-setup/SKILL.md) | Three.js scene/camera/renderer/animation-loop, resizing, controls |
| [`threejs-gltf-loading`](skills/web-engines/threejs-gltf-loading/SKILL.md) | Loading glTF/GLB + skinned animation (`GLTFLoader`/`AnimationMixer`) |
| [`threejs-materials-lighting`](skills/web-engines/threejs-materials-lighting/SKILL.md) | Materials (PBR), lights, shadows, environment maps |

#### Other engines — 11 ([`skills/other-engines/`](skills/other-engines/)) · Bevy · pygame · LÖVE · Defold · Roblox

| Skill | Scope |
|-------|-------|
| [`bevy-ecs`](skills/other-engines/bevy-ecs/SKILL.md) | Bevy app + ECS: components, systems, queries, resources, plugins (Bevy 0.20) |
| [`pygame-core`](skills/other-engines/pygame-core/SKILL.md) | pygame loop, `Surface`/`Rect`, sprites/groups, events (pygame-ce 2.5.8) |
| [`love2d-core`](skills/other-engines/love2d-core/SKILL.md) | LÖVE `load/update/draw` loop, dt-driven motion, input, states (LÖVE 11.5) |
| [`defold-core`](skills/other-engines/defold-core/SKILL.md) | Defold collections, game objects, script lifecycle, input, messages, factories, proxies, Bob build checks (Defold 1.14.0) |
| [`roblox-luau`](skills/other-engines/roblox-luau/SKILL.md) | Roblox Luau scripting: services, instances, client/server model |
| [`roblox-datastores`](skills/other-engines/roblox-datastores/SKILL.md) | Persistent data with `DataStoreService`: sessions, limits, ordered stores |
| [`roblox-ui`](skills/other-engines/roblox-ui/SKILL.md) | Roblox UI: `ScreenGui` layout, responsive scaling, safe areas, gamepad/touch navigation |
| [`roblox-networking`](skills/other-engines/roblox-networking/SKILL.md) | Remotes, server-authoritative validation, rate limiting, replication boundaries |
| [`roblox-characters`](skills/other-engines/roblox-characters/SKILL.md) | Character lifecycle: spawn/respawn scopes, `Humanoid`, rigs, `Animator` tracks |
| [`roblox-physics`](skills/other-engines/roblox-physics/SKILL.md) | Assemblies, constraints, collision/query policy, raycasts, forces, network ownership |
| [`roblox-studio-workflow`](skills/other-engines/roblox-studio-workflow/SKILL.md) | Explorer-first place editing, structure preservation, multi-context Studio verification |

### Disciplines — 15 ([`skills/disciplines/`](skills/disciplines/))

Cross-engine concepts that load alongside the detected engine skill.

| Skill | Scope |
|-------|-------|
| [`create-game-assets`](skills/disciplines/create-game-assets/SKILL.md) | Art direction and production pipeline for cohesive sprites, tiles, textures, icons, UI art, and 3D assets |
| [`game-ai`](skills/disciplines/game-ai/SKILL.md) | NPC decision-making: FSMs, behavior trees, steering, pathfinding |
| [`ai-behavior-trees-utility-ai`](skills/disciplines/ai-behavior-trees-utility-ai/SKILL.md) | Production behavior-tree runtime (Blackboard, composites, decorators, leaves) + Utility AI (curves, considerations, evaluator) + hybrid AI |
| [`procedural-gen`](skills/disciplines/procedural-gen/SKILL.md) | Noise, RNG, seeds, grid/dungeon/terrain generation |
| [`dialogue-systems`](skills/disciplines/dialogue-systems/SKILL.md) | Branching dialogue/narrative: nodes, conditions, variables (Yarn/Ink) |
| [`save-systems`](skills/disciplines/save-systems/SKILL.md) | Serialize/restore game state: formats, slots, versioning, autosave |
| [`audio-design`](skills/disciplines/audio-design/SKILL.md) | Buses/mixing, adaptive music, SFX, ducking |
| [`shader-programming`](skills/disciplines/shader-programming/SKILL.md) | Cross-engine shader concepts: vertex/fragment, UVs, common effects |
| [`physics-tuning`](skills/disciplines/physics-tuning/SKILL.md) | Tuning feel: fixed timestep, mass/drag, CCD, stability, layers |
| [`level-design`](skills/disciplines/level-design/SKILL.md) | Whitebox/blockout structure, tile/grid layout, pacing |
| [`input-systems`](skills/disciplines/input-systems/SKILL.md) | Input architecture: action mapping, rebinding, multi-device, buffering |
| [`game-feel`](skills/disciplines/game-feel/SKILL.md) | Juice: screen shake, hit-stop, tweening/easing, squash & stretch, feedback tiers |
| [`game-ui-ux`](skills/disciplines/game-ui-ux/SKILL.md) | Cross-engine HUD/menus: anchors, resolution scaling, safe areas, focus navigation |
| [`camera-systems`](skills/disciplines/camera-systems/SKILL.md) | 2D follow/deadzone/look-ahead + bounds, 3D orbit/first-person, screen-shake hook |
| [`performance-optimization`](skills/disciplines/performance-optimization/SKILL.md) | Profile-first: frame budget, CPU/GPU triage, draw calls, pooling, GC, asset budgets |

### Genres — 9 ([`skills/genres/`](skills/genres/))

Compositional templates that orchestrate engine + discipline skills; they never re-teach
primitives.

| Skill | Scope |
|-------|-------|
| [`platformer`](skills/genres/platformer/SKILL.md) | 2D platformer: run/jump/coyote-time, tiled levels, hazards, goals |
| [`roguelike`](skills/genres/roguelike/SKILL.md) | Grid/turn movement, procedural dungeons, permadeath, FOV, loot |
| [`rpg`](skills/genres/rpg/SKILL.md) | Stats/leveling, inventory, quests, dialogue, save/load, combat |
| [`fps-shooter`](skills/genres/fps-shooter/SKILL.md) | First-person controller, camera, shooting/hitscan, enemy AI |
| [`tower-defense`](skills/genres/tower-defense/SKILL.md) | Wave spawning, lane pathing, towers/targeting, economy |
| [`card-game`](skills/genres/card-game/SKILL.md) | Card data, deck/hand/discard zones, play rules, turn structure |
| [`visual-novel`](skills/genres/visual-novel/SKILL.md) | Branching script, character/bg display, text box + choices, backlog |
| [`survival-crafting`](skills/genres/survival-crafting/SKILL.md) | Resource gathering, inventory, crafting, needs, base building |
| [`puzzle`](skills/genres/puzzle/SKILL.md) | Grid/board state, match/rule resolution, undo, level progression |

### Workflows — 4 ([`skills/workflows/`](skills/workflows/))

| Skill | Scope |
|-------|-------|
| [`game-jam`](skills/workflows/game-jam/SKILL.md) | Scope/plan/execute a jam build under time limits; submit |
| [`prototype-fast`](skills/workflows/prototype-fast/SKILL.md) | Greybox a playable vertical slice quickly; cut scope; validate the fun |
| [`steam-publish`](skills/workflows/steam-publish/SKILL.md) | Steamworks onboarding: app/depots, store page, builds, release checklist |
| [`itch-publish`](skills/workflows/itch-publish/SKILL.md) | Publish/update on itch.io: project page, channels, `butler` uploads |

## Agent compatibility

Every skill here is a plain `SKILL.md` folder in the [Agent Skills](https://agentskills.io) open
standard — the format Anthropic launched as Claude Skills — metadata plus a Markdown playbook the
agent reads on demand.

The same file loads **natively** across the ecosystem: Claude Code, Claude, Cursor, Windsurf,
Cline, OpenAI Codex, Gemini CLI, GitHub Copilot, Kiro, Antigravity, VS Code, and
[many more](https://agentskills.io/clients). Oh My Pi (omp) reads the same format natively as
well. There are no editor-specific rule files to maintain
and nothing to convert.

**Install with one command.** The universal CLI detects your agent and writes the skills to the
right place:

```bash
npx skills add gamedev-skills/awesome-gamedev-agent-skills
```

**Or copy by hand.** Drop a skill's `<name>/` folder into your agent's skills directory:

| Agent | Skills directory |
|-------|------------------|
| Claude Code | `.claude/skills/` |
| Codex · Gemini CLI · GitHub Copilot · Antigravity | `.agents/skills/` _(shared path)_ |
| Cursor | `.cursor/skills/` _(also reads `.agents/skills/`)_ |
| Windsurf | `.devin/skills/` _(also reads `.windsurf/skills/`)_ |
| Cline | `.cline/skills/` |
| Kiro | `.kiro/skills/` |
| Oh My Pi (omp) | `.omp/skills/` _(also reads `.agents/skills/`)_ |

The exact per-agent paths, triggers, and the handful of optional fields that vary by agent are in
[`docs/COMPATIBILITY.md`](docs/COMPATIBILITY.md).

## Demo

One plain-English request goes in; the minimal right skills come out, then version-pinned code.
Here's the shape of a single exchange (illustrative):

```text
> add a double jump to my player

Detected Godot (project.godot). Loading godot-2d-movement for the controller
and platformer for jump feel — skipping the other 74 skills.
```

```gdscript
extends CharacterBody2D

@export var speed := 220.0
@export var jump_velocity := -380.0
@export var max_jumps := 2

var _jumps_left := max_jumps

func _physics_process(delta: float) -> void:
    if not is_on_floor():
        velocity += get_gravity() * delta   # Godot 4.7 baseline
    else:
        _jumps_left = max_jumps

    if Input.is_action_just_pressed("ui_accept") and _jumps_left > 0:
        velocity.y = jump_velocity
        _jumps_left -= 1

    velocity.x = Input.get_axis("ui_left", "ui_right") * speed
    move_and_slide()
```

## Repository layout

```
skills/        76 specialized skills, grouped by engine / discipline / genre / workflow
router/        the master router skill (+ references/)
docs/          authoring standard, installation, compatibility
templates/     SKILL.md template
scripts/       validate-skills.py, generate-site.py and tooling
tests/         regression tests for the validator
```

## Contributing

Contributions are welcome. Read [`CONTRIBUTING.md`](CONTRIBUTING.md) and the authoring standard
in [`docs/SKILL-FORMAT.md`](docs/SKILL-FORMAT.md). Every skill must pass the validator and the
rubric before merge:

```bash
python scripts/validate-skills.py
```

## Maintainer

[awesome-gamedev-agent-skills](https://github.com/gamedev-skills/awesome-gamedev-agent-skills)
was created and is maintained by [Abhishek Barali](https://github.com/AbhishekBarali).

## License

[Apache-2.0](LICENSE). See [`NOTICE`](NOTICE) for attribution and trademark notes.
