# Other engine skills

Eleven Agent Skills for Bevy 0.20, pygame-ce 2.5.8, LÖVE 11.5, Defold 1.14.0, and Roblox. Roblox
coverage includes Luau, persistence, UI, networking, characters, physics, and Studio workflow.

Each subdirectory is one skill. Existing projects keep their pinned engine or
dependency version; see [`VERSION-SUPPORT.md`](../../docs/VERSION-SUPPORT.md).

See [`docs/SKILL-FORMAT.md`](../../docs/SKILL-FORMAT.md) for the authoring standard.
