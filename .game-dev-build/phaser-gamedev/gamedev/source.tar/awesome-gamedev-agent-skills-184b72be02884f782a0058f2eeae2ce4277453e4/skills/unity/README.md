# Unity skills

Eight Agent Skills targeting Unity 6.3 LTS—C# scripting, the Input System,
physics, animation, ScriptableObjects, 2D Tilemap, AI Navigation, and builds.

Each subdirectory is one skill. Existing projects keep the version in
`ProjectSettings/ProjectVersion.txt`; see [`VERSION-SUPPORT.md`](../../docs/VERSION-SUPPORT.md).

See [`docs/SKILL-FORMAT.md`](../../docs/SKILL-FORMAT.md) for the authoring standard.
